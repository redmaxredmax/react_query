import React from 'react'
import { useDeleteTodo } from '../pages/services/mutation/useDeleteTodo'
import { queryClient } from '../config/query-client'

export const Card = ({description,title,id}) => {
    const {mutate,isPending}=useDeleteTodo()
    const deleteItem=()=>{
        mutate(id,{
            onSuccess:(res)=>{
                queryClient.invalidateQueries({queryKey:['todos']})
            }
        })
    }
  return (
    <div>
        <h2 className='font-bold'>{title}</h2>
        <p className='text-base'>{description}</p>
        <button onClick={deleteItem}  className=' border border-black rounded-lg'>{isPending?'Loading':'delete'}</button>
    </div>
  )
}
