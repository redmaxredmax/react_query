import { useQuery } from "@tanstack/react-query";
import { request } from "../../../config/request";

export const useGetTodos=()=>{
    return useQuery({
        queryKey:['todos'],
        queryFn:()=>request.get("/todos").then((res)=>res.data)
    })
}