import React from 'react'
import { Card } from '../components/card'
import { useGetTodos } from './services/query/useGetTodos'


export const Home = () => {
    const {data,isLoading}=useGetTodos()
    return (
        <div className="container">
            {
                isLoading ? <h2>Loading...</h2> : <div>
                    {data?.map((item) => <Card key={item.id}  {...item} />)}
                </div>
            }
        </div >
    )
}
